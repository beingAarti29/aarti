const { Observable } = require("rxjs");
const { getEmitHelpers } = require("typescript");

let promise = new Promise((resolve, reject) => {
setTimeout(() => {
        resolve('data recived');
        console.log('promise is resolved')
    }, 3000);    
})

async function getData() {
    let response = await promise;
    console.log(response);
}

getData();

console.log("this is prsctice");

async function test() {
    console.log("inside test func");
    const response = await fetch('https://api.github.com/users');
    console.log('after response');
    const users = await response.json();
    console.log('users rresolved');
    return users;
}

console.log('before calling test');
let a = test();
console.log('after calling');
console.log(a);
a.then(data => console.log(data))
console.log('last line')


// observable
