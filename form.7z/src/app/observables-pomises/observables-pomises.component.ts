import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CommonService } from '../common.service';

@Component({
  selector: 'app-observables-pomises',
  templateUrl: './observables-pomises.component.html',
  styleUrls: ['./observables-pomises.component.scss']
})
export class ObservablesPomisesComponent implements OnInit {

  @Input() public name: any ;
  @Output() public childEvent = new EventEmitter();
  message: string = '';

  constructor(private commonService: CommonService) { }

  ngOnInit(): void {
    console.log(this.name);
    this.commonService.teacherMessageSource$.subscribe(message => {
      if(message === 'gm') {
       alert('gm teacher')
      } else if(message === 'well done') {
        alert('ty');
      }
    });
  }

  childTestEvent() {
    this.childEvent.emit('hii this is data sharing from child to parent')
  }


//  getData() {
//    this.common_service.getEmp().subscribe((data) => {
//      console.log(data);
//    })

//  }

}
function elseif(arg0: boolean) {
  throw new Error('Function not implemented.');
}

