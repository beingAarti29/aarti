import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ObservablesPomisesComponent } from './observables-pomises.component';

describe('ObservablesPomisesComponent', () => {
  let component: ObservablesPomisesComponent;
  let fixture: ComponentFixture<ObservablesPomisesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ObservablesPomisesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ObservablesPomisesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
