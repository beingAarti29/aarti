import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from './common.service';
import { EnrollmentService } from './enrollment.service';
import { ObservablesPomisesComponent } from './observables-pomises/observables-pomises.component';
import { User } from './user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewInit {
  topics = ['Angular', 'React', 'Vue']; // bind this to select dropdown
  userModel = new User('', 'aarti@gmail.com', 7044199224, 'default', 'morning', true);
  name = 'aarti';
  message = '';
  arr = ['1', '2'];
  topicHasError = true;
  submitted = false;
  errMsg = '';
  reactiveFlag = false;
  myId = 'aarti';
  @ViewChild(ObservablesPomisesComponent) childCompRef?: ObservablesPomisesComponent;
  constructor(private commonService: CommonService,
     private enrollment_service: EnrollmentService,
     private router: Router
    ) {}

  ngOnInit(): void {
    console.log(this.myId)
  }
  ngAfterViewInit(): void {
    if(this.childCompRef !== undefined)
    this.childCompRef.message = 'msg from parent'
  }

  greetStudent() {
   this.commonService.sendMessage('gm')
  }

  aprreciateSudent() {
    this.commonService.sendMessage('well done');
  }

  validateTopic(value: string) {
    if(value === 'default') {
     this.topicHasError = true;
    } else {
      this.topicHasError = false;
    }
  }

  onSubmit(userForm: any) {
    console.log(userForm.value);
    localStorage.setItem('userData', JSON.stringify(userForm.value));
    // this.submitted = true;
    // this.enrollment_service.enroll(this.userModel)
    // .subscribe(
    // (data: any) => console.log('success', data),
    // (error: any) => this.errMsg = error.statusText
    // )
  }

  onClick() {
    this.reactiveFlag = true;
  }
}
