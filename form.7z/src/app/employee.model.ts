
export interface IEmployee {
    Id: number;
    Name: string;
    Age: number;
    };
    