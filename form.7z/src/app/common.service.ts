import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
// import { Observable } from 'rxjs';
// import { IEmployee } from './employee.model';
// import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  url: string = "src/assets/emp.json";
  private _teacherMessageSource = new Subject<string>();
  teacherMessageSource$ = this._teacherMessageSource.asObservable();
    
  constructor() { }

  // getEmp(): Observable<any> {
  //   const response = this.http.get('https://jsonplaceholder.typicode.com/users');
  //    console.log(response);
  //    return response;
  //  } 

  sendMessage(message: string) {
    this._teacherMessageSource.next(message);
  }

}
